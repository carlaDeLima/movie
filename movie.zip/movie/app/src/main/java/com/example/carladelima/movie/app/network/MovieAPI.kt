package com.example.carladelima.movie.app.network

interface MovieAPI {

}