package com.example.carladelima.movie.core

import android.support.v7.app.AppCompatActivity

abstract class BaseActivity : AppCompatActivity()