package com.example.carladelima.movie.app.network

import com.example.carladelima.movie.core.BaseNetwork

object MovieNetwork: BaseNetwork() {
}