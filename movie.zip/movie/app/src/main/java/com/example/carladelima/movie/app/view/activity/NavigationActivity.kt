package com.example.carladelima.movie.app.view.activity

import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import com.example.carladelima.movie.R
import com.example.carladelima.movie.app.view.fragment.FavoriteFragment
import com.example.carladelima.movie.core.BaseActivity
import kotlinx.android.synthetic.main.activity_navigation.*

class NavigationActivity : BaseActivity() {

    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_filmes -> {
                message.setText(R.string.title_filmes)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_favoritos -> {
                message.setText(R.string.title_favoritos)
                FavoriteFragment()
            }
        }
        false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_navigation)

        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
    }
}
