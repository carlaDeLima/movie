package com.example.carladelima.movie.core

object Paths {
    const val urlBase = "https://developers.themoviedb.org/3"
}